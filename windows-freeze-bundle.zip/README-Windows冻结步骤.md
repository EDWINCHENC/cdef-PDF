# CDEF PDF Studio — Windows 引擎冻结步骤

在任意 Windows 电脑上执行，约 10 分钟。产出两个文件发回给开发者即可。

## 0. 需要安装（一次性）

1. **Python 3.12**：https://www.python.org/downloads/ （安装时勾选 "Add python.exe to PATH"）
2. **Git for Windows**：https://git-scm.com/download/win （提供 Git Bash，一路默认安装）

验证（Git Bash 里）：`python --version` 应显示 3.12.x

## 1. 解压本包到任意目录，例如 D:\cdef-freeze\

## 2. 创建虚拟环境并装依赖（Git Bash 中执行）

```bash
cd /d/cdef-freeze          # 或你的实际路径
python -m venv .venv
.venv/Scripts/python -m pip install -r engine-requirements.txt pyinstaller
```

## 3. 冻结引擎（约 3-8 分钟）

```bash
bash scripts/freeze-engine.sh
```

## 4. 取回产物

完成后目录下会生成：

```
build/engine-dist/cdef-pdf-engine.exe    （约 130 MB）
build/engine-dist/cdef-pdf-ocr.exe       （约 100 MB）
```

把这两个文件发给开发者（微信/邮件/网盘均可），剩余打包在 macOS 侧完成。

## 常见问题

- **提示找不到 python**：确认 Python 安装时勾选了 Add to PATH，或改用 `py -3.12 -m venv .venv`
- **pip 安装慢**：可加国内镜像 `-i https://pypi.tuna.tsinghua.edu.cn/simple`
- **杀毒软件误报**：PyInstaller 产物偶有误报，允许或临时关闭后重试
- **冻结失败**：把 Git Bash 里的完整错误信息发给开发者
